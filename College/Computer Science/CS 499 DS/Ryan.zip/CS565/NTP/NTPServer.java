package CS565.NTP;

import java.math.*;
import java.net.*;

/**
 * Server for client/server Network Time Protocol (NTP)
 * interaction.
 *
 * @author Brian Cullinan
 */
public class NTPServer {

    /**
     * The program entry point
     *
     * @param args The command line arguments
     */
    public static void main(String[] args) {

        try {
            DatagramSocket server = new DatagramSocket(12345);

	    //Application loop
            while (true) {

                int delay;
		byte[] returnBytes;
		byte[] buffer = new byte[1024];

		//Listen for requests from a NTP client
		DatagramPacket recievePacket = new DatagramPacket(buffer, buffer.length);
                server.receive(recievePacket);
                System.out.println("Connection recieved from " + recievePacket.getAddress().getHostAddress());

		//Insert random delay into interaction for more interesting results on
		//the client side
		delay = (int)(Math.random()*1000);
		System.out.println("Adding delay: " + delay + " milliseconds");
		Thread.sleep(delay);

		//Return the system time in milliseconds
                returnBytes = Long.valueOf(System.currentTimeMillis()).toString().getBytes();
                server.send(new DatagramPacket(returnBytes, returnBytes.length, recievePacket.getAddress(), 12345));
                System.out.println("Data sent");

            }
        } catch (Exception ex) { ex.printStackTrace(); }
    }
    

}
