package CS565.NTP;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Client for client/server Network Time Protocol (NTP) interaction
 *
 * @author Davis Zanot
 */
public class NTPClient {

	/**
	 * The program entry point
	 *
	 * @params args Any command line args
	 */
	public static void main(String[] args) throws Exception{

		InetAddress address;
		DatagramSocket socket;
		DatagramPacket requestPacket, returnPacket;
		String serverResponse;
		byte[] message;
		byte[] buffer;
		long[] times;
		long d, oi, o;
		int port;

		//Check for and process command line args
		if(args.length < 2) {
			System.out.println("Proper usage: NTPClient IP port");
			System.exit(0);
		}
		port = Integer.parseInt(args[1]);
		message = " ".getBytes();
		buffer = new byte[1024];
		address = InetAddress.getByName(args[0]);
		System.out.println(address);

		//Send out NTP request
		times = new long[4];
		socket = new DatagramSocket(port);
		requestPacket = new DatagramPacket(message, message.length, address, port);
		returnPacket = new DatagramPacket(buffer, buffer.length);
		socket.send(requestPacket);
		System.out.println("Packet Sent");

		//Receive NTP reply
		socket.receive(returnPacket);
		System.out.println("Packet Received");
		times[2] = System.currentTimeMillis();  //T_i-2
		serverResponse = new String(returnPacket.getData(), 0, returnPacket.getLength());
		times[3] = Long.parseLong(serverResponse);//T_i-3
		
		//Send second NTP request
		times[1] = System.currentTimeMillis();  //T_i-1
		socket.send(requestPacket);

		//Receive second NTP reply		
		socket.receive(returnPacket);
	  	serverResponse = new String(returnPacket.getData(), 0, returnPacket.getLength());
		times[0] = Long.parseLong(serverResponse);    //T_i

		//Calculate offset 
		d = (times[2] - times[3])+(times[0] - times[1]);
		oi = d/2;
		o = oi + ((times[0] - times[1]) + (times[2] - times[3])/2);

		//Display values
		System.out.println("T_i-3 = "+times[3]);
		System.out.println("T_i-2 = "+times[2]);
		System.out.println("T_i-1 = "+times[2]);
		System.out.println("T_i   = "+times[0]);
		System.out.println("d_i =   "+d);
		System.out.println("o_i =   "+oi);
		System.out.println("o   =   "+o+" +- "+d);

		socket.close();
	}
}
