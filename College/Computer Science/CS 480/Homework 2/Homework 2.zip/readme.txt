compile the assign2sample.c file with g++
run the output file with the following syntax
a.exe "input file" "output file"
